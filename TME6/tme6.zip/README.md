# tme6 : Processus, Fork, Signaux

Commencer par faire un "fork" du projet, puis travailler sur votre copie.